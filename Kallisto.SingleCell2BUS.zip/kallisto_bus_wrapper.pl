# we currently do not use --threads for kallisto and bustools
use Getopt::Long;
use File::Copy;

$kallisto = 'kallisto/kallisto';
$bustools = 'bustools-master/src/bustools';

GetOptions(\%options,
  "patchesdir=s", # --patchesdir <patches> must be on command-line
  "index=s", # an FTP object
  "technology=s", # choice from a selector
  "reads=s",
);

# start writing kallisto command line :
# kallisto bus [arguments] FASTQ-files
$cmd = "$options{patchesdir}/$kallisto bus -o . -i $options{index}";
if ($options{technology} eq 'unset') {
  die "You must select the single cell technology used !\n";
} else {
  $cmd .= " -x $options{technology}";
}

# add reads to the kallisto command line
open READSLIST, $options{reads};
  @reads = <READSLIST>;
close READSLIST;
foreach $filename (@reads) {
  chomp $filename; # remove end-of-line
  $cmd .= " $filename"
}

# finish writing command line and execute it
# we redirect standard error to a file and check whether an error occurred
$cmd .= ' 1> /dev/null 2> SCREENOUTPUT';
# print "$cmd\n"; # for debugging
system($cmd);
open SCREENOUTPUT, 'SCREENOUTPUT';
while (<SCREENOUTPUT>) {
  if (/^Error/ or /^\[~warn\]/) { $error = 1}
}
close SCREENOUTPUT;
if ($error) {
  copy('SCREENOUTPUT', \*STDERR);
  unlink 'SCREENOUTPUT';
  exit (1);
} else {
  copy('SCREENOUTPUT', \*STDOUT);
  unlink 'SCREENOUTPUT';
}

# use bustools to first sort the BUS file and then export its content as text
$cmd = "$options{patchesdir}/$bustools sort -o output.sorted.bus output.bus 2>&1";
system($cmd);
$cmd = "$options{patchesdir}/$bustools text -o output.txt output.sorted.bus 2>&1";
system($cmd);

# remove unneeded file
unlink 'run_info.json';
