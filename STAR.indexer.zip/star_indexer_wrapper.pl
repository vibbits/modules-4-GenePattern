use Getopt::Long;
use File::Path qw(make_path remove_tree);

$star = 'STAR-master/bin/Linux_x86_64_static/STAR';
$Nthreads = 4;

GetOptions(\%options,
  "patchesdir=s", # --patchesdir <patches> must be on command-line
  "fastafilelist=s", # is always file 'fasta.file.list.txt'
  "GTFfile=s", # optional in interface
  "tabfile=s", # optional in interface, is always tab.file.list.txt
  "indexdir=s",
  "overhang=i",
  "indexstringlength=i",
  "binsize=i",
  "RAM=i" # in gigabyte
);

# make a directory to temporarily store the index,
#   we will later put the index in a zip file
$indexdir = $options{'indexdir'};
make_path $indexdir;

# write the STAR command line and execute it
$cmd = "$options{patchesdir}/$star --runMode genomeGenerate --runThreadN $Nthreads";
open FASTAFILELIST, $options{fastafilelist};
  @fastafiles = <FASTAFILELIST>;
close FASTAFILELIST;
$cmd .= ' --genomeFastaFiles';
foreach $fastafile (@fastafiles) {
  chop $fastafile; # remove end-of-line
  $cmd .= " $fastafile";
}
if (exists $options{'GTFfile'}) {
  $cmd .= " --sjdbGTFfile $options{'GTFfile'}";
}
if (exists $options{'tabfile'}) {
  open TABFILELIST, $options{'tabfile'};
    @tabfiles = <TABFILELIST>;
  close TABFILELIST;
  $cmd .= ' --sjdbFileChrStartEnd';
  foreach $tabfile (@tabfiles) {
    chop $tabfile; # remove end-of-line
    $cmd .= " $tabfile";
  }
}
$cmd .= " --genomeDir $options{'indexdir'}";
if (exists $options{'GTFfile'} or exists $options{'tabfile'}) {
  $cmd .= " --sjdbOverhang $options{'overhang'}";
}
$cmd .= " --genomeSAindexNbases $options{'indexstringlength'}";
$cmd .= " --genomeChrBinNbits $options{'binsize'}";
$RAM = $options{'RAM'} * 1000000000;
$cmd .= " --limitGenomeGenerateRAM $RAM";
#print "$cmd\n"; # for debugging
system($cmd);

# put the index into a zip file and remove it
# Note we need to use a system call to zip because Archive::Zip cannot handle
#   files of more than 4 Gbyte.
system "zip -r $indexdir.zip $indexdir";
#print "zip -r $indexdir.zip $indexdir\n";
remove_tree($indexdir);
