use Getopt::Long;
use Archive::Extract; # needed for custom index
use File::Copy;
use File::Path qw(make_path remove_tree); # needed for custom index

$bwa = 'BWA/bwa-0.7.17/bwa';
$Nthreads = 4;

GetOptions(\%options,
  "patchesdir=s", # --patchesdir <patches> must be on command-line
  "index=s", # an FTP object
  "reads1=s", # if reads2 not precised we assume this is the only list of reads
  "reads2=s", # optional in interface
  "type=s", # NULL, pacbio, ont2d or intractg (default NULL)
  "minseed=i",
  "seedratio=f",
  "chainwidth=i",
  "bandwidth=i",
  "mismatch=i",
  "gapopen=i",
  "gapextend=i",
  "clipping=i",
  "header=s",
  "mark=s", # yes or no (default no)
  "outputprefix=s"
);

# start writing command line and add options
# the command line is of type : bwa mem [options] <idxbase> <in1.fq> [in2.fq]
$cmd = "$options{patchesdir}/$bwa mem -t $Nthreads -A 1";
  # match score A is by default 1 and other scores scale with A
  # hence we set A to 1 and do not let user choose
$cmd .= " -o $options{outputprefix}.sam";
if ($options{type} eq 'unset') {
  $cmd .= " -k $options{minseed} -r $options{seedratio}";
  $cmd .= " -W $options{chainwidth} -w $options{bandwidth}";
  $cmd .= " -B $options{mismatch} -O $options{gapopen}";
  $cmd .= " -E $options{gapextend} -L $options{clipping}";
} else {
  $cmd .= " -x $options{type}";
}
if (exists $options{header}) {
  $header = $options{header};
  $header =~ s/ +/\\t/g;
    # needed because tabs cannot be entered from GenePattern interface
  $header =~ s/^/"/;
  $header =~ s/$/"/;
    # use " and not ' because shell might add ' around command line
  $cmd .= " -R $header";
}
if ($options{mark} eq 'yes') {
  $cmd .= ' -M';
}

# add index to command line
# a prebuilt index is in a directory (pointed to by the FTP object)
#   and has the same name as this directory
# a custom index must be in an archive file and will be extracted
#   and after the BWA run is complete the index is deleted
if (-d $options{index}) { # is prebuilt index from VIB FTP server
  $options{index} =~ /.*\/(.*)/;
  $indexrootname = $1;
  $cmd .= " $options{index}/$indexrootname";
} else { # user provided ZIP file with index
  $zipfile = $options{index};
  make_path 'INDEX';
  $indexarchive = Archive::Extract->new(archive => $zipfile);
  if (not ($indexarchive->is_tgz or $indexarchive->is_zip or $indexarchive->is_tbz)) { die "\nCustom index should be in archive with extension .zip .tar.gz .tgz .tar.bz2 .tbz\n" }
  $indexarchive->extract(to => 'INDEX') or die "\nCould not extract $zipfile. Are you sure this is a valid archive with a bowtie1 index ?\n";
  $index_error_message = "\n$zipfile\ndoes not look like a valid BWA index, it should contain files :\n\t<name>.amb\n\t<name>.ann\n\t<name>.bwt\n\t<name>.pac\n\t<name>.sa\n\n";
  @indexfiles = sort @{$indexarchive->files};
    # needed to sort because function does not always retrieve in order
  if ($#indexfiles != 4) { die $index_error_message }
  @standardextensions = ('.amb', '.ann', '.bwt', '.pac', '.sa');
  for ($i=0;$i<=4;$i++) {
    if ($indexfiles[$i] =~ /^(.*)$standardextensions[$i]$/) {
      if ($indexrootname) {
        if ($1 ne $indexrootname) {
          die $index_error_message;
        }
      } else {
        $indexrootname = $1;
      }
    } else {
      die $index_error_message;
    }
  }
  $cmd .= " INDEX/$indexrootname";
}

# add reads and output file to command line and start BWA
$cmd .= " $options{reads1}";
if (exists $options{reads2}) {
  $cmd .= " $options{reads2}";
}
$cmd .= " 2> SCREENOUTPUT";
#print "$cmd\n"; # for debugging
system($cmd);

# remove index
if ($zipfile) {
  remove_tree('INDEX');
}

# check screen output for the presence of words that suggest error and
# redirect as appropriate to STDOUT or STDERR
# based on a "grep" through the source code, let's hope it is OK
$error = 0;
open SCREENOUTPUT, 'SCREENOUTPUT';
while (<SCREENOUTPUT>) {
  if (/[Cc]annot/) { $error = 1 }
  if (/Can't/) { $error = 1 }
  if (/[Cc]ouldn't/) { $error = 1 }
  if (/fail/) { $error = 1 }
  if (/has fewer/) { $error = 1 }
  if (/invalid/) { $error = 1 }
  if (/is longer than/) { $error = 1 }
  if (/[Nn]o /) { $error = 1 }
  if (/Not /) { $error = 1 }
  if (/not started/) { $error = 1 }
  if (/Unmatched/) { $error = 1 }
  if (/unrecognized/) { $error = 1 }
}
close SCREENOUTPUT;
if ($error) {
  move('SCREENOUTPUT','stderr.txt');
} else {
  move('SCREENOUTPUT','stdout.txt');
}
