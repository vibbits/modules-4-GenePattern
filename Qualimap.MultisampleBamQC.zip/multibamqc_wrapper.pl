use Getopt::Long;
use Cwd; # needed to find working dir

$qualimap = 'qualimap_v2.2.1/qualimap';
#$Nthreads = 4; # no support for multithreading ?

GetOptions(\%options,
  "patchesdir=s", # --patchesdir <patches> must be on command-line
  "input=s", # is always input.files.list
  "names=s", # optional, is always sample.names.list
  "groups=s", # optional, is always sample.groups.list
  "regions=s", # optional, an FTP object
  "library=s", # non-strand-specific (default), strand-specific-forward
               # or trand-specific-reverse
  "windows=i",
  "homopolymer=i",
  "limits=s", # yes (default) or no
  "format=s", # PDF (defautl), HTML or PDF:HTML
  "output=s"
);
$workingdir = getcwd();

# make the data-file
open IN, "$options{input}";
while (<IN>) {
  chomp;
  push @inputfiles, $_;
}
close IN;
if (exists $options{names}) {
  open IN, "$options{names}";
  while (<IN>) {
    chomp;
    push @names, $_;
  }
  close IN;
  if ($#names != $#inputfiles) {
     die "You must provide exactly as much sample names as sample files !\n";
  }
} else { # take as name sample file name with the .bam removed
  foreach $filename (@inputfiles) {
    $filename =~ /^.*\/(.*)\.bam$/;
    $samplename = $1;
    push @names, $samplename;
  }
}
if (exists $options{groups}) {
  open IN, "$options{groups}";
  while (<IN>) {
    chomp;
    push @groups, $_;
  }
  close IN;
  if ($#groups != $#inputfiles) {
     die "You must provide exactly as much sample group labels as sample files !\n";
  }
  $groupsexist = 1;
}
open OUT, '>DATAFILE';
for ($i=0;$i<=$#inputfiles;$i++) {
  print OUT "$names[$i]\t$inputfiles[$i]";
  if ($groupsexist) { print OUT "\t$groups[$i]" }
  print OUT "\n";
}
close OUT;

# write the command line and execute it
$cmd = "$options{patchesdir}/$qualimap multi-bamqc -r -d DATAFILE";
if ($options{regions} ne '') {
  $cmd .= " -gff $options{regions} -p $options{library}";
}
$cmd .= " -nw $options{windows} -hm $options{homopolymer}";
if ($options{limits} eq 'yes') { $cmd .= ' -c' }
$cmd .= " -outformat $options{format} -outdir $workingdir -outfile $options{output}"; # need $workingdir because . does not work
$cmd .= " 2>&1 1> /dev/null | grep -v 'warning: ignoring option MaxPermSize=' > stderr.txt";
  # if everything goes fine standard error contains only line :
  # OpenJDK 64-Bit Server VM warning: ignoring option MaxPermSize=1024m; support was removed in 8.0
#print "$cmd\n"; # for debugging
system($cmd);

