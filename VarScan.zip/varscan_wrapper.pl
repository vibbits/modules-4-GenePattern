use Getopt::Long;
use File::Copy;

$varscan = 'VarScan.v2.4.4.jar';
$samtools = 'samtools-1.9/samtools';

GetOptions(\%options,
  "java=s", # --java <java> must be on command-line
  "patches=s", # --patches <patches> must be on command-line
  "input=s", # is always file 'input.file.list.txt'
  "genome=s", # an ftp object
  "report=s", # cns (the default), snp or indel
  "BAQ=s", # yes (the default) or no
  "minqual=i",
  "minmapq=i",
  "mincov=i",
  "maxcov=i",
  "minreads=i",
  "minvar=f",
  "minhomfreq=f",
  "pval=f",
  "strand=s", # 1 (the default) or 0 (yes or no in interface)
  "output=s"
);

# SAMtools mpileup is used to transform the BAM files and the output is
# directly sent to VarScan using an input redirect (we do not use a pipe
# because VarScan might timeout while waiting for an input stream). The
# standard error of SAMtools and VarScan is trapped into a file for later
# inspection.
$cmd = "bash -c '$options{java} -jar $options{patches}/$varscan mpileup2$options{report} <(";
$cmd .= "$options{patches}/$samtools mpileup -b $options{input} -f $options{genome}";
$cmd .= " -d $options{maxcov} -Q $options{minqual} -q $options{minmapq}";
  # samtools mpileup has for maxcov default 8000 and reasonable limit 1M
  # minqual is used by both samtools mpileup and varscan
  # mpileup has default 13, varscan has default 15
if ($options{BAQ} eq 'no') {
  $cmd .= ' -B';
}
$cmd .= " 2> SAMTOOLSERROR)";
$cmd .= " --variants --output-vcf 1 --min-avg-qual $options{minqual} --min-coverage $options{mincov} --min-reads2 $options{minreads} --min-var-freq $options{minvar} --min-freq-for-hom $options{minhomfreq} --p-value $options{pval} --strand-filter $options{strand}";
$cmd .= " 1> $options{output} 2> VARSCANERROR'";
#print "$cmd\n"; # for debugging
system($cmd);

# redirect standard error of software to standard output if everything went
# fine and otherwise redirect to standard error
open ERRORFILE, 'SAMTOOLSERROR';
  @lines = <ERRORFILE>;
close ERRORFILE;
$fileOK = 1;
if ($#lines != 0) { $fileOK = 0 }
if ($lines[0] !~ / samples in \w+ input files/) { $fileOK = 0 }
if ($fileOK) {
  open ERRORFILE, 'VARSCANERROR';
    @lines = <ERRORFILE>;
  close ERRORFILE;
  if ($lines[0] !~ /^Only \w+ will be reported$/) { $fileOK = 0 }
  if ($lines[$#lines] !~ / variant positions reported /) { $fileOK = 0 }
  if ($fileOK) { # means everything worked fine
    open IN, 'SAMTOOLSERROR';
    while (<IN>) { print STDOUT }
    close IN;
    print STDOUT "\n";
    open IN, 'VARSCANERROR';
    while (<IN>) { print STDOUT }
    close IN;
  } else { # means SAMtools worked but VarScan failed
    copy('SAMTOOLSERROR', \*STDOUT);
    copy('VARSCANERROR', \*STDERR);
  }
} else { # means SAMtools failed and probably VarScan could not start up
  copy('SAMTOOLSERROR', \*STDERR);
}
unlink('SAMTOOLSERROR', 'VARSCANERROR');
