# NOTE : We do not support the parameters INTERVALS, DB_SNP, REF_FLAT and
# IGNORE_SEQUENCE because making a suitable input file is tricky and few
# users will want to use it anyway. We hence also do not support the
# module RnaSeqMetrics, which needs REF_FLAT.

use Getopt::Long;

$picard = 'picard_2.21.1/picard.jar';

GetOptions(\%options,
  "rscript=s",  # --rscript <R3.2_Rscript> must be on command line
  "java=s",
  "patches=s",
  "input=s",
  "validation=s", # STRICT (default), LENIENT or SILENT
  "reference=s",
  "modules=s",  # multiple choices possible
  "unpaired=s", # true or false (default)
  "level=s", # multiple choices possible
  "output=s"
);

$options{rscript} =~ /(.*)\/Rscript$/;
$rscriptpath = $1;
$ENV{PATH} .= ":$rscriptpath";
$cmd = "$options{java} -jar $options{patches}/$picard CollectMultipleMetrics QUIET=true ASSUME_SORTED=true";
  # ASSUME_SORTED=true to avoid program to read header of SAM file to
  # figure out if it is sorted, in case this was not documented properly.
$cmd .= " I=$options{input} VALIDATION_STRINGENCY=$options{validation} R=$options{reference}";
@modules = split /,/, $options{modules};
$cmd .= ' PROGRAM=null'; # to remove default
foreach $module (@modules) {
   $cmd .= " PROGRAM=$module";
}
$cmd .= " INCLUDE_UNPAIRED=$options{unpaired}";
@levels = split /,/,  $options{level};
$cmd .= ' METRIC_ACCUMULATION_LEVEL=null'; # to remove default ALL_READS
foreach $level (@levels) {
  $cmd .= " METRIC_ACCUMULATION_LEVEL=$level";
}
$cmd .= " O=$options{output} FILE_EXTENSION=.txt 2> SCREENOUTPUT";
#print "$cmd\n"; # for debugging
system $cmd;

open SCREENOUTPUT, 'SCREENOUTPUT';
while (<SCREENOUTPUT>) {
  if (/^INFO/ or / INFO /) {
    # not interested in info about sequences processed,
    # libraries loaded and R scripts launched
  } elsif (/^WARNING.*coordinate sorted anyway/) {
    # not interested in "File reports sort order 'unsorted',
    # assuming it's coordinate sorted anyway."
  } elsif (/^WARNING.*METRIC_ACCUMULATION_LEVEL was overridden/) {
    # not interested in warning related to modules that do not use
    # METRIC_ACCUMULATION_LEVEL
  } elsif (/^$/ or /^\*\*\*\*/) {
    # to get rid of ********** "NOTE: Picard's command line syntax is changing."
  } else {
    $screenoutput .= $_;
  }
}
if ($screenoutput) {
  print STDERR $screenoutput;
}
unlink('SCREENOUTPUT');
