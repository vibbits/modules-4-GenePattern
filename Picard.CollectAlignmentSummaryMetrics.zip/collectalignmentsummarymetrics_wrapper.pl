use Getopt::Long;

$picard = 'picard_2.10.10/picard.jar';

GetOptions(\%options,
  "java=s",
  "patches=s",
  "input=s",
  "validation=s", # STRICT (default), LENIENT or SILENT
  "reference=s",
  "orientation=s", # FR, RF or TANDEM
  "bisulfite=s", # default false
  "max=i",
  "adapters=s", # string to be extracted from file content
  "level=s", # multiple choices possible
  "output=s"
);

$cmd = "$options{java} -jar $options{patches}/$picard CollectAlignmentSummaryMetrics QUIET=true ASSUME_SORTED=true";
  # ASSUME_SORTED=true to avoid program to read header of SAM file to
  # figure out if it is sorted, in case this was not documented properly.
$cmd .= " I=$options{input} VALIDATION_STRINGENCY=$options{validation} R=$options{reference} EXPECTED_PAIR_ORIENTATIONS=$options{orientation} IS_BISULFITE_SEQUENCED=$options{bisulfite} MAX_INSERT_SIZE=$options{max}";
if (exists $options{adapters}) {
  $cmd .= ' ADAPTER_SEQUENCE=null'; # to remove default
  open ADAPTERS, "$options{adapters}";
  while (<ADAPTERS>) {
    chomp;
    $cmd .= " ADAPTER_SEQUENCE=$_";
  }
}
@levels = split /,/,  $options{level};
$cmd .= ' METRIC_ACCUMULATION_LEVEL=null'; # to remove default ALL_READS
foreach $level (@levels) {
  $cmd .= " METRIC_ACCUMULATION_LEVEL=$level";
}
$cmd .= " O=$options{output} 2> SCREENOUTPUT";
#print "$cmd\n"; # for debugging
system $cmd;

open SCREENOUTPUT, 'SCREENOUTPUT';
while (<SCREENOUTPUT>) {
  if (/^INFO/ or / INFO /) {
    # not interested in info about sequences processed,
    # libraries loaded and R scripts launched
  } elsif (/^WARNING.*coordinate sorted anyway/) {
    # not interested in "File reports sort order 'unsorted',
    # assuming it's coordinate sorted anyway."
  } else {
    $screenoutput .= $_;
  }
}
if ($screenoutput) {
  print STDERR $screenoutput;
}
unlink('SCREENOUTPUT');
