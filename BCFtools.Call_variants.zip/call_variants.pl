# NOTE : this version is lacking some usefull items
use Getopt::Long;
use File::Copy;

$samtools = 'samtools-1.6/samtools';
$bcftools = 'bcftools-1.6/bcftools';
$vcfutils = 'bcftools-1.6/misc/vcfutils.pl';

GetOptions(\%options,
  "patches=s", # --patches <patches> must be on command-line
  "perl=s", # --perl <perl> must be on command line
  "input=s", # is always file 'input.file.list.txt'
  "genome=s", # an ftp object
  "ploidy=s", # 2 (the default), 1, X, Y, GRCh37, GRCh38 or custom
  "ploidyfile=s", # optional
  "BAQ=s", # yes (the default) or no
  "report=s", # both (the default), snp or indel
  "minqual=i",
  "maxcov=i",
  "output=s"
);
$patches = $options{patches};

# We use in succession 3 tools via a pipe
# 1. SAMtools mpileup
# 2. BCFtools call
# 3. BCFtools VCF utilities varscan
# The standard error of SAMtools and BCFtools is trapped into a file for
#   later inspection
$cmd = "$patches/$samtools mpileup -u -b $options{input} -f $options{genome}";
  # BCFtools call needs the "uncompressed" output generated with parameter -u
$cmd .= " -d $options{maxcov} -Q $options{minqual}";
  # minqual and maxcov are used by both samtools mpileup and vcfutils.pl
  # mpileup has defaults 13 and 8000 (and reasonable limit 1M)
  # vcfutils.pl has defaults 10 and very high
if ($options{BAQ} eq 'no') {
  $cmd .= ' -B';
}
$cmd .= " 2> SAMTOOLSERROR |";
$cmd .= " $patches/$bcftools call -vc";
if ($options{ploidy} eq '2') {
  # bcftools will complain about none ... given, assuming all sites are diploid
  $expect_samtoolserror = 1;
} elsif ($options{ploidy} eq 'custom') {
  if (not exists $options{ploidyfile}) {
    die "If you choose \"predefined ploidy\" = \"custom\" you must provide a ploidy file.\n";
  }
  &testploidyfile($options{ploidyfile});
  $cmd .= " --ploidy-file $options{ploidyfile}"; 
} else {
  $cmd .= " --ploidy $options{ploidy}";
}
if ($options{report} ne 'both') {
  $cmd .= " -V $options{report}";
    # note that param -V means EXCLUDE
}
$cmd .= " 2> BCFTOOLSERROR |";
$cmd .= " $options{perl} $patches/$vcfutils varFilter";
$cmd .= " -D $options{maxcov} -Q $options{minqual}";
$cmd .= " > $options{output}";
# print "$cmd\n"; # for debugging
system($cmd);

# redirect standard error of software to standard output if everythinh went
# fine and otherwise redirect to standard error
open ERRORFILE, 'SAMTOOLSERROR';
  @lines = <ERRORFILE>;
close ERRORFILE;
$fileOK = 1;
if ($#lines != 0) { $fileOK = 0 }
if ($lines[0] !~ / samples in \w+ input files/) { $fileOK = 0 }
if ($fileOK) {
  $fileOK = 1;
  if ($expect_samtoolserror) {
    open ERRORFILE, 'BCFTOOLSERROR';
      @lines = <ERRORFILE>;
    close ERRORFILE;
    if ($#lines != 0) { $fileOK = 0 }
    if ($lines[0] !~ /Note: none of .* given, assuming all sites are diploid/) { $fileOK = 0 }
  } else {
      if (not -z BCFTOOLSERROR) { $fileOK = 0 }
  }
  if ($fileOK) { # means everything worked fine
    open IN, 'SAMTOOLSERROR';
    while (<IN>) { print STDOUT }
    close IN;
    print STDOUT "\n";
    open IN, 'BCFTOOLSERROR';
    while (<IN>) { print STDOUT }
    close IN;
  } else { # means SAMtools worked but BCFtools failed
    copy('SAMTOOLSERROR', \*STDOUT);
    copy('BCFTOOLSERROR', \*STDERR);
  }
} else { # means SAMtools failed and probably BCFtools could not start up
  copy('SAMTOOLSERROR', \*STDERR);
}
unlink('SAMTOOLSERROR', 'BCFTOOLSERROR');

sub testploidyfile(file) {
  open PFILE, @_[0];
  $ploidyfileOK = 1;
  while (<PFILE>) {
    if (not /^(\*|\w+)\s+(\*|\d+)\s+(\*|\d+)\s+[MF]\s+[012]\n$/) { $ploidyfileOK = 0 }
  }
  close PFILE;
  if (not $ploidyfileOK) {
    die "Syntax ploidy file is not correct.\nConsult documentation for how to write it.\n";
  }
}
