use Getopt::Long;

GetOptions(\%options,
  "rseqcpydir=s", # --rseqcpydir <RSEQC> must be on command line
                  # <RSEQC> must be in genepattern.properties
  "rscript=s", # --rscript <R2.15_Rscript> must be on command line
  "input=s",
  "bed=s", # an FTP object
  "lower=i",
  "upper=i",
  "step=i",
  "minqual=i",
  "minjunction=i",
  "minintron=i",
  "output=s"
);

$options{rscript} =~ /(.*)\/Rscript$/;
$rscriptpath = $1;
$ENV{PATH} .= ":$rscriptpath";
$cmd = "$options{rseqcpydir}/junction_saturation.py -i $options{input} -r $options{bed} -l $options{lower} -u $options{upper} -s $options{step} -q $options{minqual} -v $options{minjunction} -m $options{minintron} -o $options{output} 1> /dev/null 2> SCREENOUTPUT";
#print "$cmd\n"; # for debugging
system($cmd);

#extract data from standard error and generate table in tab-separated format
open SCREENOUTPUT, 'SCREENOUTPUT';
$FAILED = 1;
$info = "% reads sampled\treads sampled\ttotal splicing junctions\tknown splicing junctions\tnovel splicing junctions\n";
while (<SCREENOUTPUT>) {
  if (/^sampling (\d+%) \((\d+)\) splicing reads. (\d+) splicing junctions. (\d+) known splicing junctions. (\d+) novel splicing junctions.$/) {
    $info .= "$1\t$2\t$3\t$4\t$5\n";
    $FAILED = 0;
  } else {
    $screenoutput .= $_;
  }
}
close SCREENOUTPUT;
if ($FAILED) {
  print STDERR $screenoutput;
} else {
  open OUT, "> $options{output}.junctionSaturation.tab";
  print OUT $info;
  close OUT;
}
system 'rm -f SCREENOUTPUT';
