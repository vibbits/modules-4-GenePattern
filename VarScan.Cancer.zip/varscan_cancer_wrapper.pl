use Getopt::Long;
use File::Copy;

$varscan = 'VarScan.v2.4.3.jar';
$samtools = 'samtools-1.6/samtools';

GetOptions(\%options,
  "java=s", # --java <java> must be on command-line
  "patches=s", # --patches <patches> must be on command-line
  "normal=s",
  "tumor=s",
  "genome=s", # an ftp object
  "BAQ=s", # yes (the default) or no
  "minqual=i",
  "minmapq=i",
  "mincovnormal=i",
  "mincovtumor=i",
  "maxcov=i",
  "minreads=i",
  "minvar=f",
  "minhomfreq=f",
  "normpur=f",
  "tumorpur=f",
  "pvalgerm=f",
  "pvalsom=f",
  "pvalhigh=f",
  "strand=s", # 1 or 0 (the default) (yes or no in interface)
  "output=s"
);

# SAMtools mpileup is used to transform the BAM files and the output is
# directly sent to VarScan using an input redirect (we do not use a pipe
# because VarScan might timeout while waiting for an input stream). The
# standard error of SAMtools and VarScan is trapped into a file for later
# inspection.
$cmd = " bash -c '$options{java} -jar $options{patches}/$varscan somatic <(";
$cmd .= "$options{patches}/$samtools mpileup -f $options{genome}";
$cmd .= " -d $options{maxcov} -Q $options{minqual} -q $options{minmapq}";
  # samtools mpileup has for maxcov default 8000 and reasonable limit 1M
  # minqual is used by both samtools mpileup and varscan
  # mpileup has default 13, varscan has default 15
if ($options{BAQ} eq 'no') {
  $cmd .= ' -B';
}
$cmd .= " $options{normal} $options{tumor} 2> SAMTOOLSERROR)";
$cmd .= " $options{output} --mpileup 1 --output-vcf 1";
$cmd .= " --min-avg-qual $options{minqual} --min-coverage-normal $options{mincovnormal} --min-coverage-tumor $options{mincovtumor} --min-reads2 $options{minreads} --min-var-freq $options{minvar} --min-freq-for-hom $options{minhomfreq} --normal-purity $options{normpur} --tumor-purity $options{tumorpur} --p-value $options{pvalgerm} --somatic-p-value $options{pvalsom} --strand-filter $options{strand}";
$cmd .= " 2> VARSCANERROR'";
#print "$cmd\n"; # for debugging
system($cmd);

# redirect standard error of software to standard output if everything went
# fine and otherwise redirect to standard error
open ERRORFILE, 'SAMTOOLSERROR';
  @lines = <ERRORFILE>;
close ERRORFILE;
$fileOK = 1;
if ($#lines != 0) { $fileOK = 0 }
if ($lines[0] !~ / samples in \w+ input files/) { $fileOK = 0 }
if ($fileOK) {
  open ERRORFILE, 'VARSCANERROR';
    @lines = <ERRORFILE>;
  close ERRORFILE;
  if ($lines[0] !~ /^Min coverage:\t\d+x for Normal, \d+x for Tumor$/) { $fileOK = 0 }
  if ($lines[$#lines] !~ /^\d+ were called Variant$/) { $fileOK = 0 }
  if ($fileOK) { # means everything worked fine
    open IN, 'SAMTOOLSERROR';
    while (<IN>) { print STDOUT }
    close IN;
    print STDOUT "\n";
    open IN, 'VARSCANERROR';
    while (<IN>) { print STDOUT }
    close IN;
  } else { # means SAMtools worked but VarScan failed
    copy('SAMTOOLSERROR', \*STDOUT);
    copy('VARSCANERROR', \*STDERR);
  }
} else { # means SAMtools failed and probably VarScan could not start up
  copy('SAMTOOLSERROR', \*STDERR);
}
unlink('SAMTOOLSERROR', 'VARSCANERROR');

# use VarScan processSomatic to sort VarScan somatic output per category
# note that VarScan processSomatic sends its comments to STDOUT
if ($fileOK) {
  print "\nSorting $options{output}.snp.vcf :\n";
  $cmd = "$options{java} -jar $options{patches}/$varscan processSomatic $options{output}.snp.vcf --p-value $options{pvalhigh} 2> /dev/null";
#print "$cmd\n"; # for debugging
  system($cmd);
  print "\nSorting $options{output}.indel.vcf :\n";
  $cmd = "$options{java} -jar $options{patches}/$varscan processSomatic $options{output}.indel.vcf --p-value $options{pvalhigh} 2> /dev/null";
#print "$cmd\n"; # for debugging
  system($cmd);
}
