use Getopt::Long;

GetOptions(\%options,
  "rseqcpydir=s", # --rseqcpydir <RSEQC> must be on command line
                  # <RSEQC> must be in genepattern.propertie
  "rscript=s", # --rscript <R2.15_Rscript> must be on command line
  "input=s",
  "min=i",
  "limit=i",
  "output=s",
);

$options{rscript} =~ /(.*)\/Rscript$/;
$rscriptpath = $1;
$ENV{PATH} .= ":$rscriptpath";
#$cmd = "read_duplication.py -i $options{input} -q $options{min} -u $options{limit} -o $options{output} &> /dev/null";
$cmd = "$options{rseqcpydir}/read_duplication.py -i $options{input} -q $options{min} -u $options{limit} -o $options{output} 1> /dev/null 2> /dev/null";
  # for a strange reason on some systems  &> /dev/null  does not work

#print "$cmd\n"; # for debugging
system($cmd);
