use Archive::Extract;

$infile = $ARGV[0];

$zipfile = Archive::Extract->new(archive => $infile);

$zipfile->extract;

@files = @{$zipfile->files};
open LIST, '>files.list';
foreach $file (@files) {
  if (-f $file) {
    print LIST "$file\n";
  }
}
close LIST;


