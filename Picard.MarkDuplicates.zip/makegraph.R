table <- read.table('table',header=T)
pdf(commandArgs(trailingOnly=T)[1])
plot(table$BIN, table$VALUE, xlab='BIN : actual sequencing coverage', ylab='VALUE : estimate of actual (non-duplicate) sequencing coverage', main='ROI')
dev.off()
