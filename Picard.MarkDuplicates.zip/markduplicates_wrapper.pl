# NOTE : maybe we should support parameters for detecting duplicates
# based on barcodes : BARCODE_TAG READ_ONE_BARCODE_TAG
# READ_TWO_BARCODE_TAG MOLECULAR_IDENTIFIER_TAG

use Getopt::Long;

$picard = 'picard_2.21.1/picard.jar';

GetOptions(\%options,
  "java=s", # --java <java> must be on command line
  "patches=s", # --patches <patches> must be on command line
  "rscript=s",  # --rscript <R3.2_Rscript> must be on command line
  "libdir=s", # --libdir <libdir> must be on command line
  "input=s",
  "validation=s", # STRICT (default), LENIENT or SILENT
  "order=s", # null (default), coordinate or queryname
  "regex=s",
  "pixel_distance=i",
  "scoring_strategy=s", # SUM_OF_BASE_QUALITIES (default), TOTAL_MAPPED_REFERENCE_LENGTH or RANDOM
  "remove=s", # all, onlyseq or none (default)
  "format=s", # SAM (default) or BAM
  "output=s",
  "index=s", # true or false (default)
  "handles=i",
  "ratio=f"
);

$cmd = "$options{java} -jar $options{patches}/$picard MarkDuplicates QUIET=true";
$cmd .= " I=$options{input} VALIDATION_STRINGENCY=$options{validation} ASO=$options{order}";
if ($options{regex}) {
  $cmd .= " READ_NAME_REGEX=\'$options{regex}\'";
}
$cmd .= " OPTICAL_DUPLICATE_PIXEL_DISTANCE=$options{pixel_distance} DS=$options{scoring_strategy}";
if ($options{remove} eq 'all') {
  $cmd .= ' REMOVE_DUPLICATES=true';
} elsif ($options{remove} eq 'onlyseq') {
  $cmd .= ' REMOVE_SEQUENCING_DUPLICATES=true';
}
$prefix = $options{output};
$cmd .= " O=$prefix.$options{format} M=$prefix.metrics.txt";
  # The output file name extension .sam or .bam determines the format created
$cmd .= " CREATE_INDEX=$options{index} MAX_FILE_HANDLES=$options{handles} SORTING_COLLECTION_SIZE_RATIO=$options{ratio}";
$cmd .= " 2> SCREENOUTPUT";
  # redirect standard error to file and later check whethet job ran well
#print "$cmd\n"; # for debugging
system $cmd;

open SCREENOUTPUT, 'SCREENOUTPUT';
while (<SCREENOUTPUT>) {
  if (/^INFO/ or / INFO /) {
    # if only INFO lines program ended without error
  } elsif (/^$/ or /^\*\*\*\*/) { 
    # to get rid of ********** "NOTE: Picard's command line syntax is changing."
  } else {
    $screenoutput .= $_;
  }
}
close SCREENOUTPUT;
if ($screenoutput) {
  print STDERR $screenoutput;
}
unlink('SCREENOUTPUT');

# make graph from metrics table
open IN, "$prefix.metrics.txt" or die "cannot open $prefix.metrics.txt\n";
open OUT, '>table';
$readingheader = 1;
while (<IN>) {
  if ($readingheader) {
    if (/^\#\# HISTOGRAM\t/) {
      $readingheader = 0;
    }
  } else {
    print OUT;
  }
}
close IN, OUT;
if (not $readingheader) { # means probably that table is OK
  $cmd = "$options{rscript} $options{libdir}makegraph.R $prefix.metrics.pdf > /dev/null";
  system $cmd;
}
unlink('table');
