use Getopt::Long;
use File::Path qw(make_path remove_tree); # needed for TMP

$Nthreads = 4;

GetOptions(\%options,
  "patchesdir=s", # --patchesdir <patches> must be on command-line
  "input=s", # is always input;files.list
  "format=s", # optional
  "contaminants=s", # optional
  "adapters=s", # optional
);

make_path("TMP");
$cmd = "$options{patchesdir}/FastQC/fastqc --dir TMP --outdir . --noextract --quiet --threads $Nthreads";
if (exists $options{format}) {
  $cmd .= " --format $options{format}";
}
if (exists $options{contaminants}) {
  $cmd .= " --contaminants $options{contaminants}";
}
if (exists $options{adapters}) {
  $cmd .= " --adapters $options{adapters}";
}
open IN, $options{input};
while (<IN>) {
  chomp;
  $cmd .= " $_";
}
close IN;
# print "$cmd\n"; # for debugging
system $cmd;
remove_tree("TMP");
