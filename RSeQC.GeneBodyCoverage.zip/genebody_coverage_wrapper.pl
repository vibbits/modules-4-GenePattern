use Getopt::Long;

GetOptions(\%options,
  "rseqcpydir=s", # --rseqcpydir <RSEQC> must be on command line
                  # <RSEQC> must be in genepattern.properties
  "rscript=s", # --rscript <R2.15_Rscript> must be on command line
  "input=s", # is always file 'input.file.list.txt'
  "bed=s", # an FTP object
  "min=i",
  "format=s",
  "output=s"
);

$options{rscript} =~ /(.*)\/Rscript$/;
$rscriptpath = $1;
$ENV{PATH} .= ":$rscriptpath";
$cmd = "$options{rseqcpydir}/geneBody_coverage.py -i ";

# Each file <basename>.bam must be accompanied by a file <basename>.bam.bai,
# while the convention for most software is to have files <basename>.bai.
# We fix this by taking in files <basename>.bai and creating soft links; 
open INFILELIST, $options{input};
  @infiles = <INFILELIST>;
close INFILELIST; 
$ERROR = 0;
foreach $infile (@infiles) {
  chomp $infile;
  if ($infile =~ /\.bam$/) {
    push @bamfiles, $infile;
  } elsif ($infile =~ /\.bai$/) {
    push @baifiles, $infile;
  } else {
    $ERROR = 1;
  }
}
if ($#bamfiles == $#baifiles) {
  for($N = 0 ; $N <= $#bamfiles ; $N++) {
    $bamfiles[$N] =~ /^.*\/(.*)\.bam$/; $bamfiles{$1} = $bamfiles[$N];
    $baifiles[$N] =~ /^.*\/(.*)\.bai$/; $baifiles{$1} = $baifiles[$N];
  }
  foreach $name (sort keys %bamfiles) {
    if (exists $baifiles{$name}) {
      $cmd .= "$bamfiles{$name},";
      system "ln -s -f $baifiles{$name} $bamfiles{$name}.bai";
    } else {
      $ERROR = 1;
    }
  }
} else {
  $ERROR = 1;
}
if ($ERROR) { die "There is a problem with the input. You must provide pairs of files that have exactly the same name and each time an extension .bam respectively .bai.\nThe files may come from different places (under Genepattern direct upload, upload from \"upload\" folder or from job output) but they must have names that are unique when not looking at the file path.\n"}
chop $cmd; # remove last ','

$cmd .= " -r $options{bed} -l $options{min} -f $options{format} -o $options{output} 1> /dev/null 2> SCREENOUTPUT";
#print "$cmd\n"; # for debugging
system($cmd);

# extract skewness index from standard error and put it in standard output
open SCREENOUTPUT, 'SCREENOUTPUT';
$FAILED = 1;
while (<SCREENOUTPUT>) {
  if (/Sample\tSkewness/) {
    $skewnessinfo = $_;
    for($i = 0 ; $i < $N ; $i++) {
      $skewnessinfo .= <SCREENOUTPUT>;
    }
    $FAILED = 0;
  } else {
    $screenoutput .= $_;
  }
}
close SCREENOUTPUT;
if ($FAILED) {
  print STDERR $screenoutput;
} else {
  print STDOUT $skewnessinfo;
}
system 'rm -f SCREENOUTPUT';
