use Getopt::Long;
use Cwd; # needed to find working dir

$qualimap = 'qualimap_v2.2.1/qualimap';
$Nthreads = 4;

GetOptions(\%options,
  "patchesdir=s", # --patchesdir <patches> must be on command-line
  "input=s",
  "regions=s", # optional, an ftp object
  # "outside=s", # yes or no (default)
     # in current version writing 2 reports works fine in interactive
     # Qualimap but is extremely slow at command line
  "library=s", # non-strand-specific (default), strand-specific-forward
               # or trand-specific-reverse
  "paired=s", # yes or no (default)
  "skip=s", # 0, 1 or 2 or none (the default)
  "gc=s",
  "windows=i",
  "homopolymer=i",
  "limits=s", # yes (default) or no
  "format=s", # PDF (defautl), HTML or PDF:HTML
  "output=s"
);
$workingdir = getcwd();

$cmd = "$options{patchesdir}/$qualimap bamqc -nt $Nthreads -bam $options{input}";
if ($options{regions} ne '') {
  $cmd .= " -gff $options{regions} -p $options{library}";
}
if ($options{paired} eq 'yes') { $cmd .= ' -ip' }
if ($options{skip} ne 'none') { $cmd .= " -sd $options{skip}" }
if ($options{gc} ne 'none') { $cmd .= " -gd $options{gc}" }
$cmd .= " -nw $options{windows} -hm $options{homopolymer}";
if ($options{limits} eq 'yes') { $cmd .= ' -c' }
$cmd .= " -outformat $options{format} -outdir $workingdir -outfile $options{output}"; # need $workingdir because . does not work
$cmd .= " 2>&1 1> /dev/null | grep -v 'warning: ignoring option MaxPermSize=' > stderr.txt";
  # if everything goes fine standard error contains only line :
  # OpenJDK 64-Bit Server VM warning: ignoring option MaxPermSize=1024m; support was removed in 8.0
#print "$cmd\n"; # for debugging
system($cmd);

