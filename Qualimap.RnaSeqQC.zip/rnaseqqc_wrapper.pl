use Getopt::Long;
use Cwd; # needed to find working dir

$qualimap = 'qualimap_v2.2.1/qualimap';

GetOptions(\%options,
  "patchesdir=s", # --patchesdir <patches> must be on command-line
  "input=s",
  "gtf=s", # optional, an ftp object
  "library=s", # non-strand-specific (default), strand-specific-forward
               # or trand-specific-reverse
  "paired=s", # yes or no (default)
  "sorted=s", # yes or no (default)
  "multi=s", # uniquely-mapped-reads (default) or proportional
  "counts=s", # optional
  "format=s", # PDF (defautl), HTML or PDF:HTML
  "output=s"
);
$workingdir = getcwd();

$cmd = "$options{patchesdir}/$qualimap rnaseq -bam $options{input} -gtf $options{gtf} -p $options{library}";
if ($options{paired} eq 'yes') { $cmd .= ' -pe' }
if ($options{sorted} eq 'yes') { $cmd .= ' -s' }
$cmd .= " -a $options{multi}";
if ($options{counts} ne '') { $cmd .= " -oc $options{counts}" }
$cmd .= " -outformat $options{format} -outdir $workingdir -outfile $options{output}"; # need $workingdir because . does not work
$cmd .= " 2>&1 1> /dev/null | grep -v 'warning: ignoring option MaxPermSize=' > stderr.txt";
  # if everything goes fine standard error contains only line :
  # OpenJDK 64-Bit Server VM warning: ignoring option MaxPermSize=1024m; support was removed in 8.0
#print "$cmd\n"; # for debugging
system($cmd);
