use Getopt::Long;

GetOptions(\%options,
  "rseqcpydir=s", # --rseqcpydir <RSEQC> must be on command line
                  # <RSEQC> must be in genepattern.properties
  "rscript=s", # --rscript <Rscript> must be on command line
  "input=s",
  "bed=s", # an FTP object
  "minqual=i",
  "minintron=i",
  "output=s"
);

$options{rscript} =~ /(.*)\/Rscript$/;
$rscriptpath = $1;
$ENV{PATH} .= ":$rscriptpath";
$cmd = "$options{rseqcpydir}/junction_annotation.py -i $options{input} -r $options{bed} -q $options{minqual} -m $options{minintron} -o $options{output} 1> /dev/null 2> SCREENOUTPUT";
#print "$cmd\n"; # for debugging
system($cmd);

# extract info about found splice junctions from standard error
# and put it in standard output. The info is between two lines
# of type ==================
open SCREENOUTPUT, 'SCREENOUTPUT';
$FAILED = 1;
while (<SCREENOUTPUT>) {
  if (/^===============/) {
     if ($LINEfound) {
       $SECONDLINEfound = 1;
       $FAILED = 0;
       $screenoutput .= $_;
     } else {
       $LINEfound = 1;
       $screenoutput .= $_;
     }
  } else {
    if ($LINEfound and not $SECONDLINEfound) {
      $screenoutput .= $_;
    }
  }
}
close SCREENOUTPUT;
if ($FAILED) {
  print STDERR "Error with input file, could not find reads and junctions.\n";
} else {
  print STDOUT $screenoutput;
}
system 'rm -f SCREENOUTPUT';
