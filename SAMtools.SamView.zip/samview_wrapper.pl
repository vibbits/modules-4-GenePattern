use Getopt::Long;

$samtools = 'samtools-1.6/samtools';

GetOptions(\%options,
  "patches=s", # --patches <patches> must be on command line
  "input=s",
  "index=s", # optional, but needed if you want chromosome
  "includeheader=s", # yes (default) or no
  "onlyheader=s", # yes or no (default)
  "showlines=i", # optional
  "chromosome=s", # optional
  "begin=i", # optional
  "end=i", # optional
  "format=s", # sam or bam (default)
  "output=s",
  "makeindex=s" # yes (default) or no
);
if (exists $options{showlines}) { $dofirstlines = 1}
$nlines = $options{showlines};
if (exists $options{chromosome}) { $doregion = 1 }
$input = $options{input};
$output = $options{output};

# Begin writing command line. Command line is of type
# samtools [options] <input file> [region] > <output file>
$cmd = "$options{patches}/$samtools view";

# If user requests restricting output to region, check that a correct
# .bai index file  has been provided and put a soft link pointing from
# where the BAM file is to where the bai file is
if ($doregion) {
  if (not exists $options{index}) {
    die "If you want to restrict the output to reads mapping to a specified region of a chromosome, you must provide an index file having the same name as the BAM file, but with extension .bai instead of .bam.\n";
  }
  $options{input} =~ /^(.*\/)(.*)\.bam$/;
  $inputpath = $1 ; $inputname = $2;
  $options{index} =~ /^.*\/(.*)\.bai$/;
  $indexname = $1;
  # print "$inputpath   $inputname   $indexname\n"; # for debugging
  if ($indexname ne $inputname) {
    die "The index file must must have the same name as the BAM file,\nbut with extension .bai instead of .bam.\n";
  }
  if (not -e "$inputpath$inputname.bai") {
    system "ln -s -f $options{index} $inputpath$inputname.bai";
  }
# also set variables $region and $region_extension
# "region" must be added to the command line and looks like chr2:1000-2000
# "region_extension is a meaningful extension to the output file name,
#   e.g. _chr2_1000_2000
  $region = $options{chromosome};
  $region_extension = "_$options{chromosome}";
  if (exists $options{begin} or exists $options{end}) {
    if (exists $options{begin}) {
      $region .= ":$options{begin}";
      $region_extension .= "_$options{begin}";
    } else {
      $region .= ':1';
      $region_extension .= '_1';
    }
    if (exists $options{end}) {
      $region .= "-$options{end}";
      $region_extension .= "_$options{end}";
    } else {
      $region_extension .= '_end';
    }
  }
}

# Continue writing the command line and execute it. We must handle
# the different cases
if ($options{format} eq 'bam') {
  $cmd .= " -b $input";
  if ($doregion) {
    $cmd .= " $region > $output$region_extension.bam";
  } else {
    $cmd .= " > $output.bam"
  }
  # print "$cmd\n"; # for debugging
  system $cmd;
} else { # format sam
  if ($options{onlyheader} eq 'yes') {
    $cmd .= " -H $input > $output.sam";
    # print "$cmd\n"; # for debugging
    system $cmd;
  } else {
    if ($options{includeheader} eq 'yes') {
      $cmd1 = $cmd ; $cmd2 = $cmd;
      if ($dofirstlines) {
        if ($doregion) {
          $cmd1 .= " -H $input > $output${region_extension}_${nlines}lines.sam";
          $cmd2 .= " $input $region | head -n $nlines >> $output${region_extension}_${nlines}lines.sam";
        } else {
          $cmd1 .= " -H $input > ${output}_${nlines}lines.sam";
          $cmd2 .= " $input | head -n $nlines >> ${output}_${nlines}lines.sam";
        }
        # print "$cmd1\n"; # for debugging
        system $cmd1;
        # print "$cmd2\n"; # for debugging
        system $cmd2;
      } else { # output all SAM lines
        if ($doregion) {
          $cmd .= " -h $input $region > $output$region_extension.sam";
        } else {
          $cmd .= " -h $input > $output.sam"
        }
        # print "$cmd\n"; # for debugging
        system $cmd;
      }
    } else { # do not include header
      $cmd .= " $input";
      if ($dofirstlines) {
        if ($doregion) {
          $cmd .= " $region | head -n $nlines > $output${region_extension}_${nlines}lines.sam";
        } else {
          $cmd .= " | head -n $nlines > ${output}_${nlines}lines.sam"
        }
      } else { # output all SAM lines
        if ($doregion) {
          $cmd .= " $region > $output$region_extension.sam";
        } else {
          $cmd .= " > $output.sam"
        }
      }
      # print "$cmd\n"; # for debugging
      system $cmd;
    }
  }
}

# Optionally index restricted output. First check that it is meaningfull
# and that creation BAM file worked (temporary file stderr.txt must be empty)
if ($options{makeindex} eq 'yes') {
  if ($doregion) {
    if ($options{format} eq 'bam') {
      if ($options{onlyheader} eq 'no') {
        if ( -z 'stderr.txt') {
          $cmd = "$options{patches}/$samtools index -b $options{output}$region_extension.bam";
          # print "$cmd\n"; # for debugging
          system $cmd;
        }
      }
    }
  }
}
