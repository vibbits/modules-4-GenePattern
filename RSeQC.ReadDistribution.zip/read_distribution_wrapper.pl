use Getopt::Long;

GetOptions(\%options,
  "rseqcpydir=s", # --rseqcpydir <RSEQC> must be on command line
                  # <RSEQC> must be in genepattern.propertie
  "input=s",
  "bed=s", # an FTP object
);

$cmd = "$options{rseqcpydir}/read_distribution.py -i $options{input} -r $options{bed} 1> readdistribution.txt 2> /dev/null";
#print "$cmd\n"; # for debugging
system($cmd);

