use Getopt::Long;
use File::Path qw(make_path remove_tree); # needed for TMP

$picard = 'picard_2.21.1/picard.jar';

GetOptions(\%options,
  "java=s", # --java <java> must be on command line
  "patches=s", # --patches <patches> must be on command lin
  "input=s",
  "validation=s", # STRICT (default), LENIENT or SILENT
  "order=s",
  "format=s",
  "output=s",
  "index=s" # true or false (default)
);

make_path("TMP"); # snappy-1.0.33-libsnappyjava.so is loaded in TMP
$cmd = "$options{java} -jar $options{patches}/$picard SortSam QUIET=true TMP_DIR=TMP";
$cmd .= " I=$options{input} VALIDATION_STRINGENCY=$options{validation} SO=$options{order} O=$options{output}.$options{format} CREATE_INDEX=$options{index}";
  # The output file name extension .sam or .bam determines the format created
$cmd .= " 2> SCREENOUTPUT";
  # redirect standard error to file and later check whethet job ran well
#print "$cmd\n"; # for debugging
system $cmd;

open SCREENOUTPUT, 'SCREENOUTPUT';
while (<SCREENOUTPUT>) {
  if (/^INFO/ or / INFO /) {
    # if only INFO lines program ended without error
  } elsif (/^$/ or /^\*\*\*\*/) { 
    # to get rid of ********** "NOTE: Picard's command line syntax is changing."
  } else {
    $screenoutput .= $_;
  }
}
if ($screenoutput) {
  print STDERR $screenoutput;
}
unlink('SCREENOUTPUT');
remove_tree("TMP");
