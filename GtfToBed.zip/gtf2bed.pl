#!/usr/bin/perl
# written by Guy Bottu for the GenePattern server of V.I.B.-B.I.T.S.
# takes as input a GTF file and writes a BED file in 12 column format
# with information about transcripts, for use with RSeqC
#
# modified for integration under GenePattern

$gtf = $ARGV[0];
$gtf =~ /.*\/([^\/]+)\.gtf3?/;
$bed = "$1.bed";

open GTF, $gtf;
open BED, ">$bed";
LINEPARSER: while (<GTF>) {
  if (/^#/) { next LINEPARSER } # skip comment lines
  @fields = split /\t/;
  $chrom = $fields[0]; $type = $fields[2]; $beginpos = $fields[3];
    $endpos = $fields[4]; $strand = $fields[6];
  chomp  $fields[8]; $documentation =  $fields[8];
  $documentation =~ /transcript_id "([^"]+)";/;
  $transcript_id = $1;
  if ($strand ne '+' and $strand ne '-') {
     print "WARNING : $transcript_id has strand information $strand\n";
  }
  if ($type eq 'transcript') {
    $chrom{$transcript_id} = $chrom;
    $strand{$transcript_id} =  $strand;
    $transcript_beginpos{$transcript_id} = $beginpos;
    $transcript_endpos{$transcript_id} = $endpos;
  } elsif ($type eq 'exon') {
    $documentation =~ /exon_number "([^"]+)";/;
    $exon_number = $1;
    $exon_beginpos{$transcript_id}[$exon_number] = $beginpos;
    $exon_endpos{$transcript_id}[$exon_number] = $endpos;
  } elsif ($type eq 'start_codon') {
    ## note : for some transcripts there are multiple start or stop codons
    ## choose those that produce the largest sequence
    if (not exists $thickpos{$transcript_id}[0]
        or ($strand eq '+' and $beginpos < $thickpos{$transcript_id}[0])
        or ($strand eq '-' and $endpos > $thickpos{$transcript_id}[1])) {
      $thickpos{$transcript_id}[0] =  $beginpos;
      $thickpos{$transcript_id}[1] =  $endpos;
    }
  } elsif ($type eq 'stop_codon') {
    if (not exists $thickpos{$transcript_id}[2]
        or ($strand eq '+' and $endpos > $thickpos{$transcript_id}[3])
        or ($strand eq '-' and $beginpos < $thickpos{$transcript_id}[2])) {
      $thickpos{$transcript_id}[2] =  $beginpos;
      $thickpos{$transcript_id}[3] =  $endpos;
    }
  } elsif ($type eq 'CDS') {
    $CDSexists{$transcript_id} = 1;
  }
}

foreach $transcript_id (keys %transcript_beginpos) {
  if (exists $thickpos{$transcript_id}[1]
      and exists $thickpos{$transcript_id}[2]) {
    if ($strand{$transcript_id} eq '+') {
      if (not $thickpos{$transcript_id}[2] > $thickpos{$transcript_id}[1]) {
        print "WARNING : problem with start and stop for transcript $transcript_id : not $thickpos{$transcript_id}[2] > $thickpos{$transcript_id}[1]\n";
        $ERROR = 1;
      }
    } elsif ($strand{$transcript_id} eq '-') {
      if (not $thickpos{$transcript_id}[2] < $thickpos{$transcript_id}[1]) {
        print "WARNING : problem with start and stop for transcript $transcript_id : not $thickpos{$transcript_id}[2] < $thickpos{$transcript_id}[1]\n";
        $ERROR = 1;
      }
    }
  }
}
if ($ERROR ) {
  die "\ncannot make BED because problem with start and stop information.\n\n";
}

foreach $transcript_id (sort keys %transcript_beginpos) {
  $beginpos = $transcript_beginpos{$transcript_id} - 1;
    ## in BED numbering starts with 0, not 1 like in GTF
  $endpos = $transcript_endpos{$transcript_id};
  print BED "$chrom{$transcript_id}\t$beginpos\t$endpos\t$transcript_id\t0\t$strand{$transcript_id}";
  if (exists $CDSexists{$transcript_id}) {
    if ($strand{$transcript_id} eq '+') {
      if (exists  $thickpos{$transcript_id}[0]) {
        $beginthick = $thickpos{$transcript_id}[0] - 1;
      } else {
        $beginthick = $beginpos;
      }
      if (exists $thickpos{$transcript_id}[3]) {
        $endthick =  $thickpos{$transcript_id}[3];
      } else {
        $endthick = $endpos;
      }
    } elsif ($strand{$transcript_id} eq '-') {
      if (exists $thickpos{$transcript_id}[2]) {
        $beginthick = $thickpos{$transcript_id}[2]- 1;
      } else {
        $beginthick = $beginpos;
      }
      if (exists $thickpos{$transcript_id}[1]) {
        $endthick = $thickpos{$transcript_id}[1];
      } else {
        $endthick = $endpos;
      }
    }
  } else {
    $beginthick = $beginpos; $endthick = $beginpos;
  }
  print BED "\t$beginthick\t$endthick";
  $blocksizes = ''; $blockstarts = '';
  $Nexons = $#{$exon_beginpos{$transcript_id}};
    ## In some GTF files the exons of a transcript on the reverse strand
    ## are numbered according to their position on the forward strand
    ## and in others according to their position on the reverse strand
  if ($Nexons == 1) {
    $blocksizes .= $exon_endpos{$transcript_id}[1] - $exon_beginpos{$transcript_id}[$exon_number] + 1 . ',';
    $blockstarts .= $exon_beginpos{$transcript_id}[1] - $transcript_beginpos{$transcript_id} . ',';
  } else {
    if ($exon_beginpos{$transcript_id}[2] > $exon_beginpos{$transcript_id}[1]) {
      foreach $exon_number (1 .. $Nexons) {
        $blocksizes .= $exon_endpos{$transcript_id}[$exon_number] - $exon_beginpos{$transcript_id}[$exon_number] + 1 . ',';
        $blockstarts .= $exon_beginpos{$transcript_id}[$exon_number] - $transcript_beginpos{$transcript_id} . ',';
      }
    } else { # (is <)
      for($exon_number = $Nexons ; $exon_number > 0 ; $exon_number--) {
        $blocksizes .= $exon_endpos{$transcript_id}[$exon_number] - $exon_beginpos{$transcript_id}[$exon_number] + 1 . ',';
        $blockstarts .= $exon_beginpos{$transcript_id}[$exon_number] - $transcript_beginpos{$transcript_id} . ',';
      }
    }
  }
  print BED "\t0\t$Nexons\t$blocksizes\t$blockstarts\n";
}
