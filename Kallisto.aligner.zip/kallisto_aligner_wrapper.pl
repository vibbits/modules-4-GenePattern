# We currently do not support the options --bootstrap-samples
# (and hence --threads), --fusion and --single-overhang
#
use Getopt::Long;
use File::Copy;

$kallisto='kallisto_linux-v0.44.0';

GetOptions(\%options,
  "patchesdir=s", # --patchesdir <patches> must be on command-line
  "index=s", # an FTP object
  "reads1=s", # if reads2 not precised we assume this is the only list of reads
  "reads2=s", # optional in interface
  "strand_spec=s", # none, forward or reverse
  "length=i", # optional in interface
  "sd=i", # optional in interface
  "bias=s", # yes or no
  "pseudo=s", # none (default), transcriptome or genome
  "gtf=s" # an FTP object
);

# start writing command line and add options ; command line is of type :
# kallisto quant [arguments] FASTQ-files
# we add --plaintext because we do not need HDF5 output for Sleuth
$cmd = "$options{patchesdir}/$kallisto/kallisto quant --plaintext -o .";
$cmd .= " -i $options{index}";
if (exists $options{reads2}) {
  if ($options{strand_spec} eq 'forward') {
    $cmd .= ' --fr-stranded';
  } elsif ($options{strand_spec} eq 'reverse') {
    $cmd .= ' --rf-stranded';
  }
} else {
  if (not exists $options{length} or not exists $options{sd}) {
    die "For single read data you must provide an estimates of\nthe average fragment length and its standard deviation.\n";
  }
  $cmd .= " --single -l $options{length} -s $options{sd}";
}
if ($options{bias} eq 'yes') { $cmd .= ' --bias' }
if ($options{pseudo} eq 'transcriptome') {
  $cmd .= ' --pseudobam';
} elsif ($options{pseudo} eq 'genome') {
  if (not exists $options{gtf}) {
    die "If you want a file with pseudo-alignments to the genome, you must provide a valid GTF file\n";
  }
  $cmd .= " --genomebam --gtf $options{gtf}";
}
  
# add reads to command line, note that you can have multiple files
# and that for paired reads the files must alternate
open READSLIST, $options{reads1};
  @reads1 = <READSLIST>;
close READSLIST;
if (exists $options{reads2}) {
  open READSLIST, $options{reads2};
    @reads2 = <READSLIST>;
  close READSLIST;
  if ($#reads1 != $#reads2) {
    die "\nThe reads must be in the same number of files!\n";
  }
  for ($i=0;$i<=$#reads1;$i++) {
    $filename = $reads1[$i];
    chomp $filename; # remove end-of-line
    $cmd .= " $filename";
    $filename = $reads2[$i];
    chomp $filename; # remove end-of-line
    $cmd .= " $filename";
  }
} else {
  foreach $filename (@reads1) {
    chomp $filename; # remove end-of-line
    $cmd .= " $filename";
  }
}

# finish writing command line and execute it
# we redirect standard error to standard input to avoid ERROR icon
$cmd .= ' 2>> stdout.txt';
#print "$cmd\n"; # for debugging
system($cmd);

# remove unneeded file (should we really do this ?)
# also mae name BAM index file more standard
if ($options{pseudo} eq 'genome') {
  move('pseudoalignments.bam.bai', 'pseudoalignments.bai');
}
unlink 'run_info.json';
