use Getopt::Long;

$kallisto='kallisto_linux-v0.43.1';
$Nthreads = 4;

GetOptions(\%options,
  "patchesdir=s", # --patchesdir <patches> must be on command-line
  "index=s", # an FTP object
  "reads1=s", # if reads2 not precised we assume this is the only list of reads
  "reads2=s", # optional in interface
  "strand_spec=s", # none, forward or reverse
  "length=i", # optional in interface
  "sd=i", # optional in interface
  "bias=s", # yes or no
  "pseudobam=s" # optional in interface
);

# if pseudo-alignment in SAM format is requested kallisto can only
# run on one thread.
$makesam = 0;
if (exists $options{pseudobam}) {
  $makesam = 1;
  $sam = $options{pseudobam};
  $sam =~ s/\.bam$/.sam/;
  if ($sam !~ /\.sam$/) { $sam .= '.sam' };
  $Nthreads = 1;
}

# start writing command line and add options ; command line is of type :
# kallisto quant [arguments] FASTQ-files > pseudobam
# we add --plaintext because we do not need HDF5 output for Sleuth
# we currently do not use recently added option --fusion
$cmd = "$options{patchesdir}/$kallisto/kallisto quant --plaintext -o .";
$cmd .= " -t $Nthreads -i $options{index}";
if (exists $options{reads2}) {
  if ($options{strand_spec} eq 'forward') {
    $cmd .= ' --fr-stranded';
  } elsif ($options{strand_spec} eq 'reverse') {
    $cmd .= ' --rf-stranded';
  }
} else {
  if (not exists $options{length} or not exists $options{sd}) {
    die "For single read data you must provide an estimates of\nthe average fragment length and its standard deviation.\n";
  }
  $cmd .= " --single -l $options{length} -s $options{sd}";
}
if ($options{bias} eq 'yes') { $cmd .= ' --bias' }
if ($makesam) { $cmd .= ' --pseudobam' }

# add reads to command line, note that you can have multiple files
# and that for paired reads the files must alternate
open READSLIST, $options{reads1};
  @reads1 = <READSLIST>;
close READSLIST;
if (exists $options{reads2}) {
  open READSLIST, $options{reads2};
    @reads2 = <READSLIST>;
  close READSLIST;
  if ($#reads1 != $#reads2) {
    die "\nThe reads must be in the same number of files!\n";
  }
  for ($i=0;$i<=$#reads1;$i++) {
    $filename = $reads1[$i];
    chomp $filename; # remove end-of-line
    $cmd .= " $filename";
    $filename = $reads2[$i];
    chomp $filename; # remove end-of-line
    $cmd .= " $filename";
  }
} else {
  foreach $filename (@reads1) {
    chomp $filename; # remove end-of-line
    $cmd .= " $filename";
  }
}

# finish writing command line and execute it
# if requested, add pseudobam to command line
# we redirect standard error to standard input to avoid ERROR icon
if ($makesam) { $cmd .= " 1> $sam" }
$cmd .= ' 2>> stdout.txt';
#print "$cmd\n"; # for debugging
system($cmd);

# remove unneeded file (should we really do this ?)
unlink 'run_info.json';
