
$vcftoolsdir = 'vcftools-vcftools-ea875e2';
$tabixdir = 'tabix-0.2.6';


# Make sure the "wrapped" script vcf-isec can find bgzip and tabix,
# as well as Vcf.pm
$ENV{PATH} = "$options{patches}$vcftoolsdir/bin:$options{patches}$tabixdir:$ENV{PATH}";
$ENV{PERL5LIB} = "$options{patches}$vcftoolsdir/share/perl5";

print $ENV{PATH};

