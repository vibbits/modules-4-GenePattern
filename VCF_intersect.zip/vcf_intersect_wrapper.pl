use Getopt::Long;

$vcftoolsdir = 'vcftools-vcftools-954e607';
$htslibdir = 'htslib-1.9';

GetOptions(\%options,
  "patches=s", # --patches <patches> must be on command line
  "perl=s", # --perl <perl> must be on command line
  "input1=s",
  "index1=s",
  "input2=s",
  "index2=s",
  "filter=s", # yes (the default) or no
  "regions=s", # optional
  "force=s", # yes (the default) or no
  "output=s"
);

# First check that the .gz.tbi index files have been provided and put soft
# links pointing from where the .gz files are to where the .gz.tbi files are.
#
$options{input1} =~ /^.*\/(.*)$/;
$inputname = $1;
$options{index1} =~ /^.*\/(.*)\.tbi$/;
$indexname = $1;
if ($indexname ne $inputname) {
  die "The index file must must have the same name as the bgzipped input file,\nbut with an extension .tbi added.\n";
}
if (not -e "$options{input1}.tbi") {
  system "ln -s -f $options{index1} $options{input1}.tbi";
}
$options{input2} =~ /^.*\/(.*)$/;
$inputname = $1;
$options{index2} =~ /^.*\/(.*)\.tbi$/;
$indexname = $1;
if ($indexname ne $inputname) {
  die "The index file must must have the same name as the bgzipped input file,\nbut with an extension .tbi added.\n";
}
if (not -e "$options{input2}.tbi") {
  system "ln -s -f $options{index2} $options{input2}.tbi";
}

# Make sure the "wrapped" script vcf-isec can find bgzip and tabix,
# as well as Vcf.pm
$ENV{PATH} = "$options{patches}/$htslibdir:$ENV{PATH}";
$ENV{PERL5LIB} = "$options{patches}/$vcftoolsdir/share/perl5";

# Write command line and execute it. We redirect standard error to file
# and check later whether program ran well (non-empty output file)
$cmd = "$options{perl} $options{patches}/$vcftoolsdir/bin/vcf-isec";
if ($options{filter} eq 'yes') { $cmd .= ' -a' }
if (exists $options{regions}) { $cmd .= " -r $options{regions}" }
if ($options{force} eq 'yes') { $cmd .= ' -f' }
$cmd .= " $options{input1} $options{input2} 1> $options{output} 2> SCREENOUTPUT";
#print "$cmd\n"; # for debugging
system $cmd;

# create error when no common VCF records were found
if (not -z SCREENOUTPUT) {
  open SCREENOUTPUT, 'SCREENOUTPUT';
  while (<SCREENOUTPUT>) { $screenoutput .= $_ }
  close SCREENOUTPUT;
}
unlink('SCREENOUTPUT');
if (-z $options{output}) { # check for failure because no output
  $error = 1;
  unlink($options{output});
} else { # check for failure because only header and no VCF records
  $Nfoundvariants = `grep -v '^#' $options{output} | wc -l`;
  if ($Nfoundvariants == 0) {  $error = 1 }
}
if ($error) {
  if ($screenoutput) { print STDERR $screenoutput }
} else {
  if ($screenoutput) { print STDOUT $screenoutput }
}
