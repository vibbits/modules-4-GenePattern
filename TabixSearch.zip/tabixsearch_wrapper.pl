use Getopt::Long;

$tabix = 'tabix-0.2.6/tabix';

GetOptions(\%options,
  "patches=s", # --patches <patches> must be on command line
  "input=s",
  "index=s",
  "includeheader=s", # yes or no (default)
  "onlyheader=s", # yes or no (default)
  "listchromosomes=s", # yes or no (default)
  "chromosome=s",
  "begin=i", # optional
  "end=i", # optional
  "output=s"
);
$input = $options{input};
$output = $options{output};

# First check that .gz.tbi index file has been provided and put a soft link
# pointing from where the .gz file is to where the .gz.tbi file is
$options{input} =~ /^.*\/(.*)$/;
$inputname = $1;
$options{index} =~ /^.*\/(.*)\.tbi$/;
$indexname = $1;
if ($indexname ne $inputname) {
  die "The index file must must have the same name as the bgzipped input file,\nbut with an extension .tbi added.\n";
}
if (not -e "$input.tbi") {
  system "ln -s -f $options{index} $input.tbi";
}

# command line is of type
# tabix [-h] <input file> <region> > <output file>
# or 
# tabix [-l] <input file> > <output file>
# The region must be added to the command line as e.g. chr2:1000-2000
# We must also add a meaningful extension to the output file name
# as e.g. _chr2_1000_2000
$cmd = "$options{patches}/$tabix";
if ($options{onlyheader} eq 'yes') {
  $cmd .= " -H $input > ${output}_header.txt";
} elsif ($options{listchromosomes} eq 'yes'){
  $cmd .= " -l $input > ${output}_chromosomes.txt";
} else {
  if ($options{includeheader} eq 'yes') {
    $cmd .= ' -h';
  }
  $cmd .= " $input";
  if (not exists $options{chromosome}) {
    die "You must precize a chromosome.\n";
  }
  $region = $options{chromosome};
  $region_extension = "_$options{chromosome}";
  if (exists $options{begin} or exists $options{end}) {
    if (exists $options{begin}) {
      $region .= ":$options{begin}";
      $region_extension .= "_$options{begin}";
    } else {
      $region .= ':0';
      $region_extension .= '_0';
    }
    if (exists $options{end}) {
      $region .= "-$options{end}";
      $region_extension .= "_$options{end}";
    } else {
      $region_extension .= '_end';
    }
  }
  $cmd .= " $region > ${output}${region_extension}.txt";
}
#print "$cmd\n"; # for debugging
system $cmd;

  


