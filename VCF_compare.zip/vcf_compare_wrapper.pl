use Getopt::Long;

$vcftoolsdir = 'vcftools-vcftools-954e607';
$htslibdir = 'htslib-1.9';

GetOptions(\%options,
  "patches=s", # --patches <patches> must be on command line
  "perl=s", # --perl <perl> must be on command line
  "libdir=s", # --libdir <libdir> must be on command line
  "rscript=s", # --rscript <R3.2_Rscript> must be on command line
  "input1=s",
  "index1=s",
  "input2=s",
  "index2=s",
  "input3=s", # optional
  "index3=s", # optional
  "input4=s", # optional
  "index4=s", # optional
  "filter=s", # yes (the default) or no
  "regions=s" # optional
);

# First check that the .gz.tbi index files have been provided and put soft
# links pointing from where the .gz files are to where the .gz.tbi files are.
# Also, count how many have been provided and warn against missing data and
# preserve "naked" input names for output name and label generation.
#
$options{input1} =~ /^.*\/(.*)\.gz$/;
$inputname1 = $1;
$options{index1} =~ /^.*\/(.*)\.gz\.tbi$/;
$indexname = $1;
if ($indexname ne $inputname1) {
  die "The index file must must have the same name as the bgzipped input file,\nbut with an extension .gz.tbi instead of .gz.\n";
}
if (not -e "$options{input1}.tbi") {
  system "ln -s -f $options{index1} $options{input1}.tbi";
}
$options{input2} =~ /^.*\/(.*)\.gz$/;
$inputname2 = $1;
$options{index2} =~ /^.*\/(.*)\.gz\.tbi$/;
$indexname = $1;
if ($indexname ne $inputname2) {
  die "The index file must must have the same name as the bgzipped input file,\nbut with an extension .gz.tbi instead of .gz.\n";
}
if (not -e "$options{input2}.tbi") {
  system "ln -s -f $options{index2} $options{input2}.tbi";
}
$NVCFs = 2;
$output = "${inputname1}_${inputname2}";
if (exists $options{input3}) {
  $options{input3} =~ /^.*\/(.*)\.gz$/;
  $inputname3 = $1;
  if (exists $options{index3}) {
    $options{index3} =~ /^.*\/(.*)\.gz\.tbi$/;
    $indexname = $1;
    if ($indexname ne $inputname3) {
      die "The index file must must have the same name as the bgzipped input file,\nbut with an extension .gz.tbi instead of .gz.\n";
    }
    if (not -e "$options{input3}.tbi") {
      system "ln -s -f $options{index3} $options{input3}.tbi";
    }
  } else {
    die "You must provide an index for input file $inputname3\n";
  }
  $NVCFs = 3;
  $output .= "_$inputname3";
}
if (exists $options{input4}) {
  $options{input4} =~ /^.*\/(.*)\.gz$/;
  $inputname4 = $1;
  if (exists $options{index4}) {
    $options{index4} =~ /^.*\/(.*)\.gz\.tbi$/;
    $indexname = $1;
    if ($indexname ne $inputname4) {
      die "The index file must must have the same name as the bgzipped input file,\nbut with an extension .gz.tbi instead of .gz.\n";
    }
    if (not -e "$options{input4}.tbi") {
      system "ln -s -f $options{index4} $options{input4}.tbi";
    }
  } else {
    die "You must provide an index for input file $inputname4\n";
  }
  $NVCFs = 4;
  $output .= "_$inputname4";
}
$output .= '_comparison';

# Make sure the "wrapped" script vcf-compare can find bgzip and tabix,
# as well as Vcf.pm
$ENV{PATH} = "$options{patches}/$htslibdir:$ENV{PATH}";
$ENV{PERL5LIB} = "$options{patches}/$vcftoolsdir/share/perl5";

# Write the vcf-compare command line and execute it.
$cmd = "$options{perl} $options{patches}/$vcftoolsdir/bin/vcf-compare";
if ($options{filter} eq 'yes') { $cmd .= ' -a' }
if (exists $options{regions}) { $cmd .= " -r $options{regions}" }
if ($options{force} eq 'yes') { $cmd .= ' -f' }
$cmd .= " $options{input1} $options{input2}";
if ($NVCFs > 2) { $cmd .= " $options{input3}" };
if ($NVCFs == 4) { $cmd .= " $options{input4}" };
$cmd .= " 1> $output 2> /dev/null";
# note : we redirect standard error because if the VCF files are hugue
# and the vcf-compare is run behind GenePattern (or Galaxy) you can get
# a "gzip: stdout: Broken pipe" error
#print "$cmd\n"; # for debugging
system $cmd;

# Check that the vcf-compare output is not empty and does not contain
# rogue lines that indicate an error has occurred.
if (-z $output) { die }
open COMPFILE, "$output";
while (<COMPFILE>) {
  if (/^#/ or /^VN/ or /^SN/) {
  } else {
    $error = 1;
  }
}
close COMPFILE;
if ($error) { die }

# parse the vcf-compare output, extract the VN lines and generate a file
# with input for the R script that makes the Venn diagram.
# Note that vcf-compare omits to write a VN line if the number of items
# is 0. We must handle the cases with 2, 3 and 4 VCF files separately.
open COMPFILE, "$output";
open DATA4VENN, '>DATA4VENN';
if ($NVCFs == 2) {
  print DATA4VENN "$inputname1\n";
  print DATA4VENN "$inputname2\n";
  $A = 0 ; $B = 0 ; $AB = 0;
  while (<COMPFILE>) {
    if (/^VN/) {
      @field = split;
      if ($#field == 3) {
        $field[2] =~ /^.*\/(.+)\.gz$/;
        if ($1 eq $inputname1) {
          $A = $field[1];
        } elsif ($1 eq $inputname2) {
          $B = $field[1];
        }
      } elsif ($#field == 5) {
        $AB = $field[1];
      }
    }
  }
  print DATA4VENN "$A\n$B\n$AB\n";
} elsif ($NVCFs == 3) {
  print DATA4VENN "$inputname1\n";
  print DATA4VENN "$inputname2\n";
  print DATA4VENN "$inputname3\n";
  $A = 0 ; $B = 0 ; $C = 0 ; $AB = 0 ; $BC = 0 ; $AC = 0 ; $ABC = 0;
  while (<COMPFILE>) {
    if (/^VN/) {
      @field = split;
      if ($#field == 3) {
        $field[2] =~ /^.*\/(.+)\.gz$/;
        if ($1 eq $inputname1) {
          $A = $field[1];
        } elsif ($1 eq $inputname2) {
          $B = $field[1];
        } elsif ($1 eq $inputname3) {
          $C = $field[1];
        }
      } elsif ($#field == 5) {
        %ispresent = ();
        $field[2] =~ /^.*\/(.+)\.gz$/;
        $ispresent{$1} = 1;
        $field[4] =~ /^.*\/(.+)\.gz$/;
        $ispresent{$1} = 1;
        if ($ispresent{$inputname1} and $ispresent{$inputname2}) {
          $AB = $field[1];
        } elsif ($ispresent{$inputname2} and $ispresent{$inputname3}) {
          $BC = $field[1];
        } elsif ($ispresent{$inputname1} and $ispresent{$inputname3}) {
          $AC = $field[1];
        }
      } elsif ($#field == 7) {
        $ABC = $field[1];
      }
    }
  }
  print DATA4VENN "$A\n$B\n$C\n$AB\n$BC\n$AC\n$ABC\n";
} elsif ($NVCFs == 4) {
  print DATA4VENN "$inputname1\n";
  print DATA4VENN "$inputname2\n";
  print DATA4VENN "$inputname3\n";
  print DATA4VENN "$inputname4\n";
  $A = 0 ; $B = 0 ; $C = 0 ; $D = 0;
  $AB = 0 ; $BC = 0 ; $CD = 0 ; $BD = 0 ; $AD = 0 ; $AC = 0;
  $ABC = 0 ; $BCD = 0 ; $ABD = 0 ; $ACD = 0;
  $ABCD = 0;
  while (<COMPFILE>) {
    if (/^VN/) {
      @field = split;
      if ($#field == 3) {
        $field[2] =~ /^.*\/(.+)\.gz$/;
        if ($1 eq $inputname1) {
          $A = $field[1];
        } elsif ($1 eq $inputname2) {
          $B = $field[1];
        } elsif ($1 eq $inputname3) {
          $C = $field[1];
        } elsif ($1 eq $inputname4) {
          $D = $field[1];
        }
      } elsif ($#field == 5) {
        %ispresent = ();
        $field[2] =~ /^.*\/(.+)\.gz$/;
        $ispresent{$1} = 1;
        $field[4] =~ /^.*\/(.+)\.gz$/;
        $ispresent{$1} = 1;
        if ($ispresent{$inputname1} and $ispresent{$inputname2}) {
          $AB = $field[1];
        } elsif ($ispresent{$inputname2} and $ispresent{$inputname3}) {
          $BC = $field[1];
        } elsif ($ispresent{$inputname3} and $ispresent{$inputname4}) {
          $CD = $field[1];
        } elsif ($ispresent{$inputname2} and $ispresent{$inputname4}) {
          $BD = $field[1];
        } elsif ($ispresent{$inputname1} and $ispresent{$inputname4}) {
          $AD = $field[1];
        } elsif ($ispresent{$inputname1} and $ispresent{$inputname3}) {
          $AC = $field[1];
        }
      } elsif ($#field == 7) {
        %ispresent = ();
        $field[2] =~ /^.*\/(.+)\.gz$/;
        $ispresent{$1} = 1;
        $field[4] =~ /^.*\/(.+)\.gz$/;
        $ispresent{$1} = 1;
        $field[6] =~ /^.*\/(.+)\.gz$/;
        $ispresent{$1} = 1;
        if (not $ispresent{$inputname4}) {
          $ABC = $field[1];
        } elsif (not $ispresent{$inputname1}) {
          $BCD = $field[1];
        } elsif (not $ispresent{$inputname3}) {
          $ABD = $field[1];
        } elsif (not $ispresent{$inputname2}) {
          $ACD = $field[1];
        }
      } elsif ($#field == 9) {
        $ABCD = $field[1];
      }
    }
  }
  print DATA4VENN "$A\n$B\n$C\n$D\n$AB\n$BC\n$CD\n$BD\n$AD\n$AC\n";
  print DATA4VENN "$ABC\n$BCD\n$ABD\n$ACD\n$ABCD\n";
}
close COMPFILE, DATA4VENN;

# run the appropriate R script
if ($NVCFs == 2) {
  $cmd = "$options{rscript} $options{libdir}plotVenn42.r &> /dev/null";
} elsif ($NVCFs == 3) {
  $cmd = "$options{rscript} $options{libdir}plotVenn43.r &> /dev/null";
} elsif ($NVCFs == 4) {
  $cmd = "$options{rscript} $options{libdir}plotVenn44.r &> /dev/null";
}
#print "$cmd\n"; # for debugging
system $cmd;

unlink 'DATA4VENN';
