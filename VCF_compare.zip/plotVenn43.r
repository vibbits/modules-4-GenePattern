library(grid)
library(colorfulVennPlot)
lines <- scan('DATA4VENN','character')
labels <- lines[1:3]
data <- as.numeric(lines[4:10])
names(data) <- c('100','010','001','110','011','101','111')
pdf('Venn.pdf')
plotVenn3d(data, labels, rot=3,shrink=0.5)
# we need to shrink the text and slightly rotate plot+text to make sure
# the labels are not written over each other when they are long
dev.off()
