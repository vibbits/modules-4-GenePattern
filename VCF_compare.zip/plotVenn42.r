library(grid)
library(colorfulVennPlot)
lines <- scan('DATA4VENN','character')
labels <- lines[1:2]
data <- as.numeric(lines[3:5])
pdf('Venn.pdf')
plotVenn2d(data, labels)
dev.off()
