library(grid)
library(colorfulVennPlot)
lines <- scan('DATA4VENN','character')
#labels <- lines[1:4]
labels <- c('VCF1','VCF2','VCF3','VCF4')
# note : if the labels are long the graph is compressed horizontally and
# a bug/misfeature in the code makes that we cannot fix it by setting
# "rot" and "shrink", hence we replace the labels by shorter ones.
data <- as.numeric(lines[5:19])
names(data) <- c('1000','0100','0010','0001','1100','0110','0011','0101','1001','1010','1110','0111','1101','1011','1111')
pdf('Venn.pdf')
plotVenn4d(data, labels)
dev.off()
