use feature 'switch';
no warnings; # needed to avoid 'given is experimental' warning on some systems
use Getopt::Long;

$htslibdir = 'htslib-1.9';

GetOptions(\%options,
  "patches=s", # --patches <patches> must be on command line
  "input=s",
  "format=s", # bed, gff, sam, vcf or other
  "assumesorted=s", # yes or no (default)
  "output=s",
  "comment=s", # optional
  "sequencepos=i", # optional
  "beginpos=i", # optional
  "endpos=i", # optional
  "basis=i" # 0 or 1 (default)
);
$bgzip = "$options{patches}/$htslibdir/bgzip";
$tabix = "$options{patches}/$htslibdir/tabix";
$input = $options{input};
$output = "$options{output}.gz";
if ($options{assumesorted} eq 'yes') { $assumesorted = 1 }
if ($options{format} eq 'other') { $customize = 1 }

# Collect information about the format and put it in the variables
#    $commentsymbol  $sequencepos  $beginpos  $endpos
# For formats without end of region information we assume endpos = beginpos
# Prepare also a UNIX sort filter.
if ($customize ){
  if (exists $options{comment}) {
    $commentsymbol = $options{comment};
  }
  if (exists $options{sequencepos}) {
    $sequencepos = $options{sequencepos};
  } else {
    die "You must choose a format from the \"input format\" selector or otherwise\ntype in a customized format description with at least the positions\nof the columns with sequence name and begin of region of interest.\n";
  }
  if (exists $options{beginpos}) {
    $beginpos = $options{beginpos};
  } else {
    die "You must choose a format from the \"input format\" selector or otherwise\ntype in a customized format description with at least the positions\nof the columns with sequence name and begin of region of interest.\n";
  }
  if (exists $options{endpos}) {
    $endpos =  $options{endpos};
  } else {
    $endpos = $beginpos;
  }
  $filter = "-k ${sequencepos}V,${sequencepos} -k ${beginpos}n,${beginpos}";
  if ($beginpos != $endpos) { $filter .= " -k ${endpos}n,${endpos}" }
} else {
  given ($options{format} ){
    when ("bed") { $commentsymbol = '#'; $filter = "-k 1V,1 -k 2n,2 -k 3n,3" }
    when ("gff") { $commentsymbol = '#'; $filter = "-k 1V,1 -k 4n,4 -k 5n,5" }
    when ("sam") { $commentsymbol = '@'; $filter = "-k 3V,3 -k 4n,4" }
    when ("vcf") { $commentsymbol = '#'; $filter = "-k 1V,1 -k 2n,2" }
  }
}

# If the input file is sorted already we can directly run bgzip. Otherwise
# we must run in succession grep (to separate the header from the data),
# sort (to sort the data according to sequence name, start position and
# end position) and bgzip. We do this with a pipe in order to gain speed.
if ($assumesorted) {
  $cmd = "$bgzip -c $input > $output";
} else {
  if ($commentsymbol) {
    $cmd = "(grep '^$commentsymbol' $input ; grep -v '^$commentsymbol' $input | sort $filter) | $bgzip > $output";
  } else {
    $cmd = "sort $filter $input | $bgzip > $output";
  }
}
#print "$cmd\n"; # for debugging
system($cmd);

# Run tabix on the bgzip output file
if ($customize) {
  $cmd = "$tabix -s $sequencepos -b $beginpos -e $endpos";
  if ($commentsymbol) { $cmd .= " -c $commentsymbol" }
  if ($options{basis} == 0) { $cmd .= ' -0' }
  $cmd .= " $output";
} else {
  $cmd = "$tabix -p $options{format} $output";
}
#print "$cmd\n"; # for debugging
system($cmd);
