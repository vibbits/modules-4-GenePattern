use Getopt::Long;

GetOptions(\%options,
  "rseqcpydir=s", # --rseqcpydir <RSEQC> must be on command line
                  # <RSEQC> must be in genepattern.properties
  "input=s",
  "bed=s", # an FTP object
  "sample=i",
  "min=i",
);

$cmd = "$options{rseqcpydir}/infer_experiment.py -i $options{input} -r $options{bed} -s $options{sample} -q $options{min} 1> inferexperiment.txt 2> /dev/null";
#print "$cmd\n"; # for debugging
system($cmd);
