use Getopt::Long;
use File::Copy;

$varscan = 'VarScan.v2.4.3.jar';
$samtools = 'samtools-1.6/samtools';

GetOptions(\%options,
  "java=s", # --java <java> must be on command-line
  "patches=s", # --patches <patches> must be on command-line
  "father=s",
  "mother=s",
  "child=s",
  "genome=s", # an ftp object
  "BAQ=s", # yes (the default) or no
  "minqual=i",
  "minmapq=i",
  "mincov=i",
  "maxcov=i",
  "minreads=i",
  "minvar=f",
  "minhomfreq=f",
  "pval=f",
  "adjminreads=i",
  "adjminvar=f",
  "adjpval=f",
  "output=s"
);

# SAMtools mpileup is used to transform the BAM files and the output is
# directly sent to VarScan using an input redirect (we do not use a pipe
# because VarScan might timeout while waiting for an input stream). The
# standard error of SAMtools and VarScan is trapped into a file for later
# inspection.
$cmd = "bash -c '$options{java} -jar $options{patches}/$varscan trio <(";
$cmd .= "$options{patches}/$samtools mpileup -f $options{genome}";
$cmd .= " -d $options{maxcov} -Q $options{minqual} -q $options{minmapq}";
  # samtools mpileup has for maxcov default 8000 and reasonable limit 1M
  # minqual is used by both samtools mpileup and varscan
  # mpileup has default 13, varscan has default 15
if ($options{BAQ} eq 'no') {
  $cmd .= ' -B';
}
$cmd .= " $options{father} $options{mother} $options{child}";
$cmd .= " 2> SAMTOOLSERROR) $options{output}";
$cmd .= " --min-avg-qual $options{minqual} --min-coverage $options{mincov} --min-reads2 $options{minreads} --min-var-freq $options{minvar} --min-freq-for-hom $options{minhomfreq} --p-value $options{pval}";
$cmd .= " --adj-min-reads2 $options{adjminreads} --adj-var-freq $options{adjminvar} --adj-p-value $options{adjpval}";
$cmd .= " 2> VARSCANERROR'";
#print "$cmd\n"; # for debugging
system($cmd);

# redirect standard error of software to standard output if everything went
# fine and otherwise redirect to standard error
open ERRORFILE, 'SAMTOOLSERROR';
  @lines = <ERRORFILE>;
close ERRORFILE;
$fileOK = 1;
if ($#lines != 0) { $fileOK = 0 }
if ($lines[0] !~ / samples in \w+ input files/) { $fileOK = 0 }
if ($fileOK) {
  @lines = (); # re-initialize @lines since we will push items into it
  open ERRORFILE, 'VARSCANERROR';
    # VARSCANERROR, if there was no error, contains the input parameters,
    # an unpredictable number of "waiting for" lines, the number of
    # variants found and an unpredictable number of "re-called" lines.
  while (<ERRORFILE>) {
    if (not /^Input stream not ready, waiting for/) { push @lines, $_ }
  }
  close ERRORFILE;
  if ($lines[0] !~ /^SNPs will be output to /) { $fileOK = 0 }
  if ($lines[16] !~ /^\d+ de novo mutations reported \(/) { $fileOK = 0 }
  if ($fileOK) { # means everything worked fine
    open IN, 'SAMTOOLSERROR';
    while (<IN>) { print STDOUT }
    close IN;
    print STDOUT "\n";
    open IN, 'VARSCANERROR';
    while (<IN>) { print STDOUT }
    close IN;
  } else { # means SAMtools worked but VarScan failed
    copy('SAMTOOLSERROR', \*STDOUT);
    copy('VARSCANERROR', \*STDERR);
  }
} else { # means SAMtools failed and probably VarScan could not start up
  copy('SAMTOOLSERROR', \*STDERR);
}
unlink('SAMTOOLSERROR', 'VARSCANERROR');

# make files with only the strongly predicted de novo mutations (STATUS=3)
if ($fileOK) {
  open IN, "$options{output}.snp.vcf";
  open OUT, ">$options{output}.snp_denovo.vcf";
  while (<IN>) {
    if (/^##source=VarScan2/) {
      print OUT "##source=VarScan2 : subset with de novo mutations\n";
    }
    if (/^#/) { print OUT }
    if (/STATUS=3/) { print OUT }
  }
  close IN, OUT;
  open IN, "$options{output}.indel.vcf";
  open OUT, ">$options{output}.indel_denovo.vcf";
  while (<IN>) {
    if (/^##source=VarScan2/) {
      print OUT "##source=VarScan2 : subset with de novo mutations\n";
    }
    if (/^#/) { print OUT }
    if (/STATUS=3/) { print OUT }
  }
  close IN, OUT;
} 
