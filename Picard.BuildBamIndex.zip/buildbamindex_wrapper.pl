use Getopt::Long;

$picard = 'picard_2.21.1/picard.jar';

GetOptions(\%options,
  "java=s",
  "patches=s",
  "input=s",
  "validation=s" # STRICT (default), LENIENT or SILENT
);

$cmd = "$options{java} -jar $options{patches}/$picard BuildBamIndex QUIET=true";
  # note: BuildBamIndex has no ASSUME_SORTED parameter
$infile = $options{input};
if ($infile =~ /([^\/]+)\.bam$/) {
  $outfile = "$1.bai";
  $cmd .= " I=$infile O=$outfile";
  # need to put outfile on command line or program will by default
  # put bai file in GenePattern temp location
} else {
  die "input file must have extension .bam\n";
}
$cmd .= " VALIDATION_STRINGENCY=$options{validation} 2> /dev/null";
#print "$cmd\n"; # for debugging
$fail = system $cmd; # BuildBamIndex exits with status 1 in case of error
if ($fail != 0) {
  die "The indexing did not succeed. Are you sure $infile is a valid alignment file in BAM format sorted in coordinate order ?\n";
}
