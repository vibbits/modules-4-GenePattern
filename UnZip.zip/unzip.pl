use Archive::Extract;

$infile = $ARGV[0];

$zipfile = Archive::Extract->new(archive => $infile);
if (not ($zipfile->is_gz or $zipfile->is_zip or $zipfile->is_bz2)) {die "The input file should be a single file that has been compressed\n  by gzip, zip or bzip2 and has an extension .gz, .zip or .bz2\n";}
$zipfile->extract;
