use Getopt::Long;

$kallisto='kallisto_linux-v0.44.0';

GetOptions(\%options,
  "patchesdir=s", # --patchesdir <patchesdir> must be on command-line
  "fastafilelist=s", # is always file 'fasta.file.list.txt'
  "indexfile=s",
  "kmer=i" # uneven number between 3 and 31
);

# check that kmer is uneven
$kmer = $options{kmer};
if (not $kmer % 2) { die "Kmer size must be an uneven number !\n"; }

# write the command line and execute it
# we redirect standard error to standard input to avoid ERROR icon
$cmd = "$options{patchesdir}/$kallisto/kallisto index -i $options{indexfile}";
$cmd .= " --make-unique -k $kmer";
open FASTAFILELIST, $options{fastafilelist};
  @fastafiles = <FASTAFILELIST>;
close FASTAFILELIST;
foreach $fastafile (@fastafiles) {
  chop $fastafile; # remove end-of-line
  $cmd .= " $fastafile";
}
$cmd .= " 2>> stdout.txt";
#print "$cmd\n"; # for debugging
system($cmd);
