use Getopt::Long;

GetOptions(\%options,
  "rseqcpydir=s", # --rseqcpydir <RSEQC> must be on command line
                  # <RSEQC> must be in genepattern.properties
  "rscript=s", # --rscript <R2.15_Rscript> must be on command line
  "input=s",
  "bed=s", # an FTP object
  "sample=i",
  "lower=i",
  "upper=i",
  "step=i",
  "output=s"
);

$options{rscript} =~ /(.*)\/Rscript$/;
$rscriptpath = $1;
$ENV{PATH} .= ":$rscriptpath";
$cmd = "$options{rseqcpydir}/inner_distance.py -i $options{input} -r $options{bed} -k $options{sample} -l $options{lower} -u $options{upper} -s $options{step} -o $options{output} 1> SCREENOUTPUT 2> /dev/null";
#print "$cmd\n"; # for debugging
system($cmd);

#extract statistics from intercepted standard output
open SCREENOUTPUT, 'SCREENOUTPUT';
$FAILED = 1;
while (<SCREENOUTPUT>) {
  if (/Name\tMean\tMedian/) {
    $statinfo = $_;
    $statinfo .= <SCREENOUTPUT>;
    $FAILED = 0;
  }
}
close SCREENOUTPUT;
if ($FAILED) {
  print STDERR "Error with data or range, could not generate histogram.\n";
} else {
  print STDOUT $statinfo;
}
system 'rm -f SCREENOUTPUT';
